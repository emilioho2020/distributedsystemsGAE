package ds.gae.entities;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.google.appengine.api.datastore.Key;

import ds.gae.EMF;

import javax.persistence.GenerationType;

@Entity
public class Car {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Key id;
    private String type;
	@OneToMany(cascade = CascadeType.ALL)
    private Set<Reservation> reservations;

    /***************
     * CONSTRUCTOR *
     ***************/
    
	public Car() {};
	
    public Car(CarType type) {
        this.type = type.getUniqueName();
        this.reservations = new HashSet<Reservation>();
    }

    /******
     * ID *
     ******/
    
    public Key getId() {
    	return id;
    }
    
    /************
     * CAR TYPE *
     ************/
    
    public CarType getType() {
    	EntityManager em = EMF.get().createEntityManager();
		try {
			return (CarType) em.createNamedQuery("getCarTypes").getResultList().get(0);
		}
		finally {em.close();
		}
		}
    
	
	 
    
    public String getCarTypeUniqueName(){
    	return type;
    }
    /****************
     * RESERVATIONS *
     ****************/
    
    public Set<Reservation> getReservations() {
    	return reservations;
    }

    public boolean isAvailable(Date start, Date end) {
        if(!start.before(end))
            throw new IllegalArgumentException("Illegal given period");

        for(Reservation reservation : reservations) {
            if(reservation.getEndDate().before(start) || reservation.getStartDate().after(end))
                continue;
            return false;
        }
        return true;
    }
    
    public void addReservation(Reservation res) {
        reservations.add(res);
    }
    
    public void removeReservation(Reservation reservation) {
        // equals-method for Reservation is required!
        reservations.remove(reservation);
    }
}